<?php
/**
 * Wallbox Billing — Admin/Setup-Seite
 */

$res = 0;
if (!$res && !empty($_SERVER['CONTEXT_DOCUMENT_ROOT'])) {
    $res = @include $_SERVER['CONTEXT_DOCUMENT_ROOT'].'/main.inc.php';
}
$tmp  = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME'];
$tmp2 = realpath(__FILE__);
$i = strlen($tmp) - 1;
$j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) {
    $i--;
    $j--;
}
if (!$res && $i > 0 && file_exists(substr($tmp, 0, $i + 1).'/main.inc.php')) {
    $res = @include substr($tmp, 0, $i + 1).'/main.inc.php';
}
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, $i + 1)).'/main.inc.php')) {
    $res = @include dirname(substr($tmp, 0, $i + 1)).'/main.inc.php';
}
if (!$res && file_exists('../../../../main.inc.php')) {
    $res = @include '../../../../main.inc.php';
}
if (!$res && file_exists('../../../../../main.inc.php')) {
    $res = @include '../../../../../main.inc.php';
}
if (!$res) {
    die('Include of main fails');
}

require_once DOL_DOCUMENT_ROOT.'/core/lib/admin.lib.php';
require_once __DIR__.'/../lib/wallboxbilling.lib.php';

if (!$user->admin) {
    accessforbidden();
}

$langs->loadLangs(array('admin', 'wallboxbilling@wallboxbilling'));

// --- Auto-Migration: fehlende Spalten nachrüsten ohne Konsolen-Zugriff ---
$resql_cols = $db->query("SHOW COLUMNS FROM ".MAIN_DB_PREFIX."wallbox_rfid");
if ($resql_cols) {
    $existing = array();
    while ($col = $db->fetch_object($resql_cols)) {
        $existing[] = strtolower($col->Field);
    }
    $db->free($resql_cols);
    if (!in_array('price_kwh', $existing)) {
        $db->query("ALTER TABLE ".MAIN_DB_PREFIX."wallbox_rfid ADD COLUMN price_kwh DECIMAL(10,4) DEFAULT NULL AFTER label");
    }
    if (!in_array('entity', $existing)) {
        $db->query("ALTER TABLE ".MAIN_DB_PREFIX."wallbox_rfid ADD COLUMN entity INTEGER DEFAULT 1 AFTER active");
        $db->query("UPDATE ".MAIN_DB_PREFIX."wallbox_rfid SET entity = 1 WHERE entity IS NULL");
    }
}

$action = GETPOST('action', 'aZ09');

// --- Aktionen verarbeiten ---
if ($action === 'update') {
    if (!checkToken()) {
        accessforbidden('InvalidToken');
    }
    $price = price2num(GETPOST('WALLBOXBILLING_DEFAULT_PRICE', 'alpha'));
    dolibarr_set_const($db, 'WALLBOXBILLING_DEFAULT_PRICE', $price, 'chaine', 0, '', $conf->entity);
    setEventMessages($langs->trans('SetupSaved'), null, 'mesgs');
}

if ($action === 'save_rfid') {
    if (!checkToken()) {
        accessforbidden('InvalidToken');
    }
    $user_id  = GETPOST('user_id', 'int');
    $rfid_hex = trim(GETPOST('rfid_hex', 'alpha'));
    $price    = price2num(GETPOST('price_kwh', 'alpha'));

    if ($user_id > 0 && !empty($rfid_hex)) {
        $rfid_hash = hash('sha256', strtoupper($rfid_hex));
        dol_syslog('wallboxbilling: save RFID for user '.$user_id.' hash='.substr($rfid_hash, 0, 16).'...', LOG_INFO);

        $db->begin();
        $sql = "DELETE FROM ".MAIN_DB_PREFIX."wallbox_rfid WHERE fk_user = ".(int)$user_id
            ." AND entity = ".(int)$conf->entity;
        $db->query($sql);

        $sql = "INSERT INTO ".MAIN_DB_PREFIX."wallbox_rfid"
            ." (fk_user, rfid_hash, label, price_kwh, active, entity, date_creation)"
            ." VALUES (".(int)$user_id
            .", '".$db->escape($rfid_hash)."'"
            .", '".$db->escape($rfid_hex)."'"
            .", ".(float)$price
            .", 1"
            .", ".(int)$conf->entity
            .", '".$db->idate(dol_now())."'"
            .")";

        if ($db->query($sql)) {
            $db->commit();
            setEventMessages($langs->trans('RFIDHashSaved'), null, 'mesgs');
        } else {
            $db->rollback();
            setEventMessages($db->lasterror(), null, 'errors');
        }
    } elseif ($user_id > 0 && empty($rfid_hex)) {
        // RFID löschen falls Feld geleert
        $sql = "DELETE FROM ".MAIN_DB_PREFIX."wallbox_rfid WHERE fk_user = ".(int)$user_id
            ." AND entity = ".(int)$conf->entity;
        if ($db->query($sql)) {
            setEventMessages($langs->trans('RFIDHashSaved'), null, 'mesgs');
        } else {
            setEventMessages($db->lasterror(), null, 'errors');
        }
    }
}

// --- Ausgabe ---
// Token einmal generieren und in alle Formulare einsetzen
$token = newToken();

$page_title = $langs->trans('WallboxBillingSetup');
llxHeader('', $page_title);

$head = wallboxbillingPrepareHead();
print dol_get_fiche_head($head, 'setup', $page_title, -1, 'fa-bolt');

// --- Konfiguration ---
print '<form method="POST" action="'.$_SERVER['PHP_SELF'].'">';
print '<input type="hidden" name="token" value="'.$token.'">';
print '<input type="hidden" name="action" value="update">';

print '<table class="noborder centpercent">';
print '<tr class="liste_titre"><td colspan="2">'.$langs->trans('WallboxConfiguration').'</td></tr>';
print '<tr><td class="fieldrequired">'.$langs->trans('DefaultPricePerKwh').'</td>';
print '<td><input type="text" name="WALLBOXBILLING_DEFAULT_PRICE" class="flat" size="8"'
    .' value="'.getDolGlobalString('WALLBOXBILLING_DEFAULT_PRICE', '0.30').'">'
    .' &euro;/kWh</td></tr>';
print '</table>';
print '<div class="center" style="margin-top:10px">';
print '<input type="submit" class="button" value="'.$langs->trans('Save').'">';
print '</div></form>';

print '<br>';

// --- RFID-Verwaltung ---
print load_fiche_titre($langs->trans('WallboxUserRFIDManagement'));

print '<table class="noborder centpercent">';
print '<tr class="liste_titre">';
print '<td>'.$langs->trans('User').'</td>';
print '<td>'.$langs->trans('RFIDHex').'</td>';
print '<td>'.$langs->trans('RFIDHash').'</td>';
print '<td>'.$langs->trans('PricePerKWh').'</td>';
print '<td>'.$langs->trans('Action').'</td>';
print '</tr>';

$sql = "SELECT u.rowid, u.login, u.lastname, u.firstname,"
    ." r.rfid_hash, r.label as rfid_hex, r.price_kwh"
    ." FROM ".MAIN_DB_PREFIX."user u"
    ." LEFT JOIN ".MAIN_DB_PREFIX."wallbox_rfid r ON r.fk_user = u.rowid AND r.entity = ".(int)$conf->entity
    ." WHERE u.statut = 1 AND u.entity = ".(int)$conf->entity
    ." ORDER BY u.login";

$resql = $db->query($sql);
if ($resql) {
    while ($obj = $db->fetch_object($resql)) {
        $current_price = !empty($obj->price_kwh) ? price2num($obj->price_kwh) : getDolGlobalString('WALLBOXBILLING_DEFAULT_PRICE', '0.30');
        print '<form method="POST" action="'.$_SERVER['PHP_SELF'].'">';
        print '<input type="hidden" name="token" value="'.$token.'">';
        print '<input type="hidden" name="action" value="save_rfid">';
        print '<input type="hidden" name="user_id" value="'.(int)$obj->rowid.'">';
        print '<tr class="oddeven">';
        print '<td>'.dol_escape_htmltag($obj->login).' ('.dol_escape_htmltag($obj->firstname.' '.$obj->lastname).')</td>';
        print '<td><input type="text" name="rfid_hex" class="flat" size="16"'
            .' value="'.dol_escape_htmltag((string)$obj->rfid_hex).'" placeholder="EFCD083E"></td>';
        print '<td><span class="opacitymedium small">';
        print !empty($obj->rfid_hash) ? substr($obj->rfid_hash, 0, 16).'…' : '—';
        print '</span></td>';
        print '<td><input type="text" name="price_kwh" class="flat" size="6"'
            .' value="'.dol_escape_htmltag((string)$current_price).'" placeholder="0.30"> &euro;/kWh</td>';
        print '<td><input type="submit" class="button smallpaddingimp" value="'.$langs->trans('Save').'"></td>';
        print '</tr></form>';
    }
    $db->free($resql);
} else {
    print '<tr><td colspan="5" class="error">'.$db->lasterror().'</td></tr>';
}
print '</table>';

print dol_get_fiche_end();
llxFooter();
?>
